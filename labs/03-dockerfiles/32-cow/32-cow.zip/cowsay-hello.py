# En este programa, una vaca saluda al curso de Docker
import cowsay
cowsay.cow("¡Hola curso de Docker!")